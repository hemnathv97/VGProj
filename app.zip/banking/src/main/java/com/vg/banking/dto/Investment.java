package com.vg.banking.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="userDetails")
public class Investment {
	
	@Id
	@Column(name="investment_id" ,length=15)
	private String id;
	
	@Column(name="income", length=10)
	private long income;
	
	@Column(name="expenses", length=10)
	private long exp;
	
	@Column(name="asset",length=20)
	private long asset;
	
	
	@Column(name="life_ex",length=5)
	private int lifeExp;


	public String getId() {
		return id;
	}


	public void setId(String investmentId) {
		this.id = investmentId;
	}



	public long getIncome() {
		return income;
	}


	public void setIncome(long income) {
		this.income = income;
	}


	public long getExp() {
		return exp;
	}


	public void setExp(long expenses) {
		this.exp = expenses;
	}


	public long getAsset() {
		return asset;
	}


	public void setAsset(long asset) {
		this.asset = asset;
	}


	public int getLifeExp() {
		return lifeExp;
	}


	public void setLifeExpe(int lifeExpectancy) {
		this.lifeExp = lifeExpectancy;
	}


	public Investment(String investmentId, long income, long expenses, long asset, int lifeExpectancy) {
		super();
		this.id = investmentId;
		this.income = income;
		this.exp = expenses;
		this.asset = asset;
		this.lifeExp = lifeExpectancy;
	}


	public Investment() {
		super();
	}


	@Override
	public String toString() {
		return "Investment [investmentId=" + id + "," + "income=" + income + ", expenses="
				+ exp + ", asset=" + asset + ", lifeExpectancy=" + lifeExp + "]";
	}
	
	
	

}
