package com.vg.banking.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vg.banking.dao.InvestmentRepo;
import com.vg.banking.dto.Investment;

@Service
public class InvestmentServiceImpl implements InvestmentService {
	@Autowired
	InvestmentRepo iRepo;

	@Override
	public Investment add(Investment investment) {

		System.out.println("in service impl");
		return iRepo.save(investment);

	}

	@Override
	public boolean resultById(Investment inv) {

		boolean flag=false;
		double eReturn=0;
		eReturn = ((inv.getAsset() + (inv.getIncome()-inv.getExp())*12*6) * Math.pow(1.06,inv.getLifeExp()));
		if(eReturn>=480000)
			flag=true;
		else 
			flag=false;

		return flag;

		/*double eReturn=0;
		eReturn = ((investment.getAsset() + (investment.getIncome()-investment.getExpenses())*12*6) * Math.pow(1.06,investment.getLifeExpectancy()));
		if(eReturn>=480000)
			return true;
		else
		   return false;*/
	}

	@Override
	public List<Investment> getInv() {
		return iRepo.findAll();
	}



}
