import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Investor } from '../model/investor';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  url: string = '../assets/utility/investorDetails.json';
  status: string;
  
  constructor(private http: HttpClient) { }

  getData(): Observable<Investor[]> {
    return this.http.get<Investor[]>(this.url);
  }
}
